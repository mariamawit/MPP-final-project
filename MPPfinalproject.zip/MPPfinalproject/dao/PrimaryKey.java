package interfaces;

public interface PrimaryKey {
	public String getPrimaryKey();
}
